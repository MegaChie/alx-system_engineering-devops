Done the cmd challenge with as expected of the ALX's project that is named: Command line for the win.
the project is to solve the tasks using bash to run on the virtual machine of the website.
