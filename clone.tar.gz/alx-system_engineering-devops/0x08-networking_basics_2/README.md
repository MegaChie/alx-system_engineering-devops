This folder contains my solution to ALX's project of the name: 0x07. Networking basics #1
