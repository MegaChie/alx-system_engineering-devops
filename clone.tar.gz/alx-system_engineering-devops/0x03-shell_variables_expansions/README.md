this folder contains exexutables that function as per discribed on ALX's Shell, init files, variables and expansions project
