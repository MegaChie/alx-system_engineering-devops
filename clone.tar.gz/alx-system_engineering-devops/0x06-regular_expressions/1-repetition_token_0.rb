#!/usr/bin/env ruby
# text
puts ARGV[0].scan(/hbt{2,5}n/).join
