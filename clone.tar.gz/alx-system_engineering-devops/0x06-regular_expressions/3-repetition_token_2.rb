#!/usr/bin/env ruby
# text
puts ARGV[0].scan(/hbt+n/).join
