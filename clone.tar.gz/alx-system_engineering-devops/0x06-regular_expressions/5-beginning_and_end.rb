#!/usr/bin/env ruby
# text
puts ARGV[0].scan(/h.n/).join
