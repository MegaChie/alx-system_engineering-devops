# 0x02-shell_redirections
this folder contains a set of files thatN are goiung to do a set of things. As outlined on the project named as the same as the folder, the tasks are as numbered as apearing on the task list:
1. prints “Hello, World”, followed by a new line to the standard output.
2. displays a confused smiley "(Ôo)'.
3. Display the content of the /etc/passwd file.
4. Display the content of /etc/passwd and /etc/hosts.
5. Display the last 10 lines of /etc/passwd.
6. Display the first 10 lines of /etc/passwd.
7. displays the third line of the file iacta.
8. creates a file named exactly \*\\'"Best School"\'\\*$\?\*\*\*\*\*:) containing the text Best School ending by a new line.
9. writes into the file ls_cwd_content the result of the command ls -la. If the file ls_cwd_content already exists, it should be overwritten. If the file ls_cwd_content does not exist, create it.
10. duplicates the last line of the file iacta.
11. deletes all the regular files (not the directories) with a .js extension that are present in the current directory and all its subfolders.
12. counts the number of directories and sub-directories in the current directory.
13. displays the 10 newest files in the current directory.
14. takes a list of words as input and prints only words that appear exactly once.
15. Display lines containing the pattern “root” from the file /etc/passwd.
16. Display the number of lines that contain the pattern “bin” in the file /etc/passwd.
17. Display lines containing the pattern “root” and 3 lines after them in the file /etc/passwd.
18. Display all the lines in the file /etc/passwd that do not contain the pattern “bin”.
19. Display all lines of the file /etc/ssh/sshd_config starting with a letter.
20. Replace all characters A and c from input to Z and e respectively.
21. Create a script that removes all letters c and C from input.
22. reverse its input.
23. displays all users and their home directories, sorted by users.
24. finds all empty files and directories in the current directory and all sub-directories.
25. lists all the files with a .gif extension in the current directory and all its sub-directories.
26. decodes acrostics that use the first letter of each line.
27. parses web servers logs in TSV format as input and displays the 11 hosts or IP addresses which did the most requests.
