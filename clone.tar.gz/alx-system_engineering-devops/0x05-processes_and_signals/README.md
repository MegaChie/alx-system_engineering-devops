This folder contains my solution to ALX's project of the name: 0x05. Processes and signals
